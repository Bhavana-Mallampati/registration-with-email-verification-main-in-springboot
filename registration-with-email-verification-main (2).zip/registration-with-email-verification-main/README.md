# Spring boot user registration and email verification

Refer to this article: https://deeppatel23.medium.com/user-registration-with-email-verification-in-java-and-spring-boot-699cb832ad2c


